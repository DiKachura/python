import sqlite3

with sqlite3.connect('db/database.db') as db:
    cursor = db.cursor()

    cursor.execute('''CREATE TABLE Products (
        id INTEGER PRIMARY KEY, 
        product_name TEXT, 
        product_price REAL)''')
    cursor.execute('''CREATE TABLE Services (
        id INTEGER PRIMARY KEY, 
        service_name TEXT, 
        service_price REAL,
        product_id INTEGER,
        FOREIGN KEY(product_id) REFERENCES Products(product_id))''')
    cursor.execute('''CREATE TABLE Orders (
        order_id INTEGER PRIMARY KEY, 
        client_name TEXT, 
        address TEXT,
        total_cost REAL,
        service_id INTEGER,  
        FOREIGN KEY(service_id) REFERENCES Services(service_id))''')
