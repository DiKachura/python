#!/usr/bin/python

import cgi
import sqlite3
import xml.etree.ElementTree as ET

entities = ['products', 'services', 'orders']

tags = {
    'products': ['id', 'product_name', 'product_price'],
    'services': ['id', 'service_name', 'service_price', 'product_id'],
    'orders': ['order_id', 'client_name', 'address', 'total_cost', 'service_id'],
}

def get_all_from(conn, table):
    cur = conn.cursor()
    cur.execute(f"SELECT * FROM {table}")
    data = cur.fetchall()
    return data

def create_xml():

    root = ET.Element('root')
    # tree = ET.ElementTree()

    for i, entity in enumerate(entities):

        ent = ET.Element('entity')
        root.append(ent)

        data = get_all_from(con, entity)
        for record in data:
            config = ET.Element(entity)
            config = ET.SubElement(config, entity)
            ent.append(config)
            for idx, tag in enumerate(tags[entity]):
                rec = ET.SubElement(config, tag)
                rec.text = str(record[idx])

    tree = ET.ElementTree(root)

    tree.write(f"cgi-bin/products.xml", encoding='utf-8', xml_declaration=True)

form = cgi.FieldStorage()
product_name = form.getfirst("product_name", "")
product_price = form.getfirst("product_price", "")

service_name = form.getfirst("service_name", "")
service_price = form.getfirst("service_price", "")

client_name = form.getfirst("client_name", "")
address = form.getfirst("address", "")
total_cost = form.getfirst("total_cost", "")

if (product_name == "" or product_price == "" or service_name == "" or service_price == "" or
        client_name == "" or address == "" or total_cost == ""):
    flag = False
else:
    flag = True

print("Content-type: text/html\n\n")
print("""<!DOCTYPE HTML>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Обработка данных форм</title>
        </head>
        <style>
             body{
                background-image: linear-gradient(#413f41,#696969,#a3a2a3,#c6c6c7, #d1d1d1);
                font-size:16px;
                font-family: 'Times New Roman', serif;
                align-content: center
            }
        </style>
        <body>
        <h1 style="text-align: center; margin-top: 60px">"""
      )
if flag:
    print("""Данные успешно записаны!""")
    con = sqlite3.connect('db/database.db')
    cur = con.cursor()

    # Записали данные из формы в бд
    sql1 = "INSERT INTO Products (product_name, product_price) VALUES(?,?);"
    var1 = (product_name, product_price)
    cur.execute(sql1, var1)
    con.commit()

    cur.execute("SELECT last_insert_rowid()")
    product_id = cur.fetchone()[0]

    sql2 = "INSERT INTO services (service_name, service_price, product_id) VALUES(?,?,?)"
    var2 = (service_name, service_price, product_id)
    cur.execute(sql2, var2)
    con.commit()

    cur.execute("SELECT last_insert_rowid()")
    service_id = cur.fetchone()[0]

    sql3 = """INSERT INTO Orders (client_name, address, total_cost, service_id)
                   VALUES(?,?,?,?)"""

    var3 = (client_name, address, total_cost, service_id)

    cur.execute(sql3, var3)
    con.commit()

    # Достаём данные из бд и сохраняем в XML
    create_xml()

    sqlite_select_query = """SELECT * FROM Products"""
    cur.execute(sqlite_select_query)
    records = cur.fetchall()
    print("""<style>
    table {
    margin: auto;
    text-align: centre;
    border-collapse: separate;
    border-spacing: 5px;
    background: #ECE9E0;
    color: #656665;
    border: 16px solid #ECE9E0;
    border-radius: 20px;
    }
    th {
    font-size: 18px;
    padding: 10px;
    }
    td {
    background: #F5D7BF;
    padding: 10px;
    }</style>""")
    print()
    print(f"""<table>
  <tr>
    <td>id</td>
    <td>Наименование продукта</td>
    <td>Цена</td>
  </tr>""")
    for row in records:
        print(f"""
      <tr>
        <td>{row[0]}</td>
        <td>{row[1]}</td>
        <td>{row[2]}</td>
      </tr>""")

    print("""</table>""")

    sqlite_select_query = """SELECT * FROM Services"""
    cur.execute(sqlite_select_query)
    records = cur.fetchall()
    print()
    print(f"""<table style="margin-top: 60px">
      <tr>
        <td>id</td>
        <td>Наименование услуги</td>
        <td>Цена</td>
        <td>id продукта</td>
      </tr>""")
    for row in records:
        print(f"""
          <tr>
            <td>{row[0]}</td>
            <td>{row[1]}</td>
            <td>{row[2]}</td>
            <td>{row[3]}</td>
          </tr>""")
    print("""</table>""")

    sqlite_select_query = """SELECT * FROM Orders"""
    cur.execute(sqlite_select_query)
    records = cur.fetchall()
    print()
    print(f"""<table style="margin-top: 60px">
          <tr>
            <td>Номер заказа</td>
            <td>Имя клиента</td>
            <td>Адрес</td>
            <td>Полная стоимость</td>
            <td>id услуги</td>
          </tr>""")
    for row in records:
        print(f"""
              <tr>
                <td>{row[0]}</td>
                <td>{row[1]}</td>
                <td>{row[2]}</td>
                <td>{row[3]}</td>
                <td>{row[4]}</td>
              </tr>""")
    print("""</table>""")
    print()



else:
    print("""Ошибка! Заполнены не все поля!""")
print("""</h1>
        </body>
        </html>""")







