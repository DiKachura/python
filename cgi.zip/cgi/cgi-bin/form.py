#!/usr/bin/python

import cgi
import sqlite3
import xml.etree.ElementTree as ET
con = sqlite3.connect('db/database.db')


entities = ['products', 'services', 'orders']

tags = {
    'products': ['id', 'product_name', 'product_price'],
    'services': ['id', 'service_name', 'service_price'],
    'orders': ['order_id', 'client_name', 'address', 'total_cost', 'service_id', 'product_id'],
}

def get_all_from(conn, table):
    cur = conn.cursor()
    cur.execute(f"SELECT * FROM {table}")
    data = cur.fetchall()
    return data

def create_xml():

    root = ET.Element('root')

    for i, entity in enumerate(entities):

        ent = ET.Element('entity')
        root.append(ent)

        data = get_all_from(con, entity)
        for record in data:
            config = ET.Element(entity)
            config = ET.SubElement(config, entity)
            ent.append(config)
            for idx, tag in enumerate(tags[entity]):
                rec = ET.SubElement(config, tag)
                rec.text = str(record[idx])

    tree = ET.ElementTree(root)

    tree.write(f"cgi-bin/products.xml", encoding='utf-8', xml_declaration=True)

form = cgi.FieldStorage()
product_name = form.getfirst("product_name", "")
product_price = form.getfirst("product_price", "")

service_name = form.getfirst("service_name", "")
service_price = form.getfirst("service_price", "")

client_name = form.getfirst("client_name", "")
address = form.getfirst("address", "")
total_cost = form.getfirst("total_cost", "")
service_id = form.getfirst("service_id", "")
product_id = form.getfirst("product_id", "")




print("Content-type: text/html\n\n")
print("""<!DOCTYPE HTML>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Обработка данных форм</title>
        </head>
        <style>
             body{
                background-image: linear-gradient(#413f41,#696969,#a3a2a3,#c6c6c7, #d1d1d1);
                font-size:16px;
                font-family: 'Times New Roman', serif;
                align-content: center
            }
        </style>
        <body>
        <h1 style="text-align: center; margin-top: 60px">"""
      )
"""if flag:"""
print("""Данные успешно записаны!""")



cur = con.cursor()


print("""
<style>
a {
  display: inline-block;
  padding: 10px 20px;
  background-color: #fff;
  border-radius: 5px;
  color: #000000;
  text-decoration: none;
  font-size: 16px;
  font-weight: bold;
}

a:hover {
  background-color: #808080;
}
</style>""")
print("""<a href="../menu.html">На главную</a>""")


def delete_record(table_name, record_id):
    cursor = con.cursor()
    cursor.execute('DELETE FROM {} WHERE id=?'.format(table_name), (record_id,))
    con.commit()
    cursor.close()

# Обработчик запросов DELETE
if 'id' in form.keys() and 'table' in form.keys() and form.getvalue('id').isdigit():
    record_id = form.getvalue('id')
    table_name = form.getvalue('table')
    delete_record(table_name, record_id)

    # Перенаправляем на страницу с обновленной таблицей
    print(f'<meta http-equiv="refresh" content="0; url=/cgi-bin/form.py">')
    exit()


print(f'''<form method="POST" action="">
            <input type="text" name="id" placeholder="Введите ID" />
            <select name="table">
                <option value="Products">Продукты</option>
                <option value="Services">Услуги</option>
                <option value="Orders">Заказы</option>
            </select>
            <input type="submit" value="Удалить" />
        </form>''')





# Записали данные из формы в бд
if product_name and product_price:
    sql1 = "INSERT INTO Products (product_name, product_price) VALUES(?,?);"
    var1 = (product_name, product_price)
    cur.execute(sql1, var1)
    con.commit()


if service_name and service_price:
    sql2 = "INSERT INTO services (service_name, service_price) VALUES(?,?)"
    var2 = (service_name, service_price)
    cur.execute(sql2, var2)
    con.commit()


if client_name and address and total_cost and service_id and product_id:
    sql3 = """INSERT INTO Orders (client_name, address, total_cost, service_id, product_id)
                   VALUES(?,?,?,?,?)"""

    var3 = (client_name, address, total_cost, service_id, product_id)

    cur.execute(sql3, var3)
    con.commit()

# Достаём данные из бд и сохраняем в XML
create_xml()

sqlite_select_query = """SELECT * FROM Products"""
cur.execute(sqlite_select_query)
records = cur.fetchall()
print("""<style>
table {
margin: auto;
text-align: centre;
border-collapse: separate;
border-spacing: 5px;
background: #ECE9E0;
color: #656665;
border: 16px solid #ECE9E0;
border-radius: 20px;
}
th {
font-size: 18px;
padding: 10px;
}
td {
background: #F5D7BF;
padding: 10px;
}</style>""")
print()


print(f"""<table>
<tr>
<td>id</td>
<td>Наименование продукта</td>
<td>Цена</td>
</tr>""")
for row in records:
    print(f"""
  <tr>
    <td>{row[0]}</td>
    <td>{row[1]}</td>
    <td>{row[2]}</td>
  </tr>""")

print("""</table>""")

sqlite_select_query = """SELECT * FROM Services"""
cur.execute(sqlite_select_query)
records = cur.fetchall()
print()
print(f"""<table style="margin-top: 60px">
  <tr>
    <td>id</td>
    <td>Наименование услуги</td>
    <td>Цена</td>
  </tr>""")
for row in records:
    print(f"""
      <tr>
        <td>{row[0]}</td>
        <td>{row[1]}</td>
        <td>{row[2]}</td>
      </tr>""")
print("""</table>""")

sqlite_select_query = """SELECT * FROM Orders"""
cur.execute(sqlite_select_query)
records = cur.fetchall()
print()


print(f"""<table style="margin-top: 60px">
      <tr>
        <td>Номер заказа</td>
        <td>Имя клиента</td>
        <td>Адрес</td>
        <td>Полная стоимость</td>
        <td>id услуги</td>
        <td>id продукта</td>
      </tr>""")
for row in records:
    print(f"""
          <tr>
            <td>{row[0]}</td>
            <td>{row[1]}</td>
            <td>{row[2]}</td>
            <td>{row[3]}</td>
            <td>{row[4]}</td>
            <td>{row[5]}</td>
          </tr>""")
print("""</table>""")
print()


print("""</h1>
        </body>
        </html>""")
#annangel_2000@mail.ru
#настроить админку в джанго, добавление удаление.






