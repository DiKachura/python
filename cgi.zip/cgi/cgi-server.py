from http.server import HTTPServer, CGIHTTPRequestHandler
derver_address = ("localhost", 8000)
httpd = HTTPServer(derver_address, CGIHTTPRequestHandler)
httpd.serve_forever()