from django import forms
from .models import Product, Service, Order

class ProductForm(forms.ModelForm):

  class Meta:
    model = Product
    fields = ['name', 'description', 'price']
    labels = {
      'name': 'Название товара',
      'description': 'Описание товара',
      'price': 'Цена товара',
    }

class ServiceForm(forms.ModelForm):

  class Meta:
    model = Service
    fields = ['name', 'description', 'price']
    labels = {
      'name': 'Название услуги',
      'description': 'Описание услуги',
      'price': 'Цена услуги',
    }

class OrderForm(forms.ModelForm):

  class Meta:
    model = Order
    fields = ['product', 'service']
    labels = {
      'product': 'Товар',
      'service': 'Услуга',
    }