from django.shortcuts import render, redirect
from .models import Product, Service, Order

def index(request):
    products = Product.objects.all()

    context = {
        'products': products,
        'title': 'Главная страница',
        'cat_selected': 0,
    }
    return render(request, 'products.html', context=context)

def products(request):
  context = {
      'title': 'Товары',
      'products': Product.objects.all(),
  }
  return render(request, 'products.html', context)

def services(request):
  context = {
      'title': 'Услуги',
      'services': Service.objects.all(),
  }
  return render(request, 'services.html', context)

def orders(request):
  context = {
      'title': 'Заказы',
      'orders': Order.objects.all(),
  }
  return render(request, 'orders.html', context)

def delete_order(request, order_id):
  order = Order.objects.get(id=order_id)
  order.delete()
  return redirect('orders')

def delete_product(request, product_id):
  product = Product.objects.get(id=product_id)
  product.delete()
  return redirect('products')

def delete_service(request, service_id):
  service = Service.objects.get(id=service_id)
  service.delete()
  return redirect('services')



from django.shortcuts import render, redirect
from .models import Product, Service, Order
from .forms import ProductForm, ServiceForm, OrderForm

def new_product(request):
  if request.method == 'POST':
    form = ProductForm(request.POST)
    if form.is_valid():
      form.save()
      return redirect('products')
  else:
    form = ProductForm()
    context = {
      'title': 'Новый товар',
      'form': form,
      'action': 'Добавить',
    }
  return render(request, 'form.html', context)

def new_service(request):
  if request.method == 'POST':
    form = ServiceForm(request.POST)
    if form.is_valid():
      form.save()
      return redirect('services')
  else:
    form = ServiceForm()
    context = {
      'title': 'Новая услуга',
      'form': form,
      'action': 'Добавить',
    }
  return render(request, 'form.html', context)

def new_order(request):
  if request.method == 'POST':
    form = OrderForm(request.POST)
    if form.is_valid():
      form.save()
      return redirect('orders')
  else:
    form = OrderForm()
    context = {
      'title': 'Новый заказ',
      'form': form,
      'action': 'Добавить',
    }
  return render(request, 'form.html', context)