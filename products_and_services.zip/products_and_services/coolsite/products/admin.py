from django.contrib import admin
from django.utils.safestring import mark_safe

from .models import *

class ProductAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'description', 'price')
    list_display_links = ('id', 'name')
    search_fields = ('name',)
    save_on_top = True

class ServiceAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'description', 'price')
    list_display_links = ('id', 'name')
    search_fields = ('name',)


class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'product', 'service', 'date')
    list_display_links = ('id', )

admin.site.register(Product, ProductAdmin)
admin.site.register(Service, ServiceAdmin)
admin.site.register(Order, OrderAdmin)

admin.site.site_title = 'Админ-панель сайта о продуктах и услугах'
admin.site.site_header = 'Админ-панель сайта о продуктах и услугах'