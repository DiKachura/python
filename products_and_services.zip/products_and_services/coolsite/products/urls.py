from django.urls import path
from .views import *

urlpatterns = [
  path('', index, name='home'),
  path('products/', products, name='products'),
  path('services/', services, name='services'),
  path('orders/', orders, name='orders'),
  path('delete_order/<int:order_id>/', delete_order, name='delete_order'),
  path('delete_product/<int:product_id>/', delete_product, name='delete_product'),
  path('delete_service/<int:service_id>/', delete_service, name='delete_service'),
  path('new_product/', new_product, name='new_product'),
  path('new_service/', new_service, name='new_service'),
  path('new_order/', new_order, name='new_order'),
]