from django.db import models

class Product(models.Model):
  name = models.CharField(max_length=100, verbose_name='наименование товара')
  description = models.TextField(verbose_name='описание товара')
  price = models.DecimalField(max_digits=7, decimal_places=2, verbose_name='цена товара')

  def __str__(self):
      return self.name

  class Meta:
      verbose_name = 'товар'
      verbose_name_plural = 'товары'

class Service(models.Model):
  name = models.CharField(max_length=100, verbose_name='наименование услуги')
  description = models.TextField(verbose_name='описание услуги')
  price = models.DecimalField(max_digits=7, decimal_places=2, verbose_name='цена услуги')

  def __str__(self):
      return self.name

  class Meta:
      verbose_name = 'услуга'
      verbose_name_plural = 'услуги'

class Order(models.Model):
  product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name='товар', related_name='orders')
  service = models.ForeignKey(Service, on_delete=models.CASCADE, verbose_name='услуга', related_name='orders')
  date = models.DateField(auto_now_add=True, verbose_name='дата заказа')

  def __str__(self):
      return '{} - {}'.format(self.product.name, self.service.name)

  class Meta:
      verbose_name = 'заказ'
      verbose_name_plural = 'заказы'